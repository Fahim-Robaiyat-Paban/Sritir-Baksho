import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { IdCard, RotateCcw } from "lucide-react";
import ShareResult from "@/components/quiz/ShareResult";
import Icon from "@/components/ui/Icon";
import Button from "@/components/ui/Button";
import SectionTitle from "@/components/ui/SectionTitle";
import { getResult, resultShares, results } from "@/api/quiz";
import { toBn } from "@/lib/utils/format";

export const generateStaticParams = () => results.map((result) => ({ type: result.id }));

export const generateMetadata = async ({ params }) => {
  const { type } = await params;
  const result = getResult(type);
  if (!result) return { title: "ফলাফল পাওয়া যায়নি" };
  return {
    title: `আমি ছিলাম ${result.title}`,
    description: result.text,
    alternates: { canonical: `/quiz/result/${type}` },
    openGraph: { title: `আমি ছিলাম ${result.title}`, description: "তুমি কী ছিলে? দুই মিনিটে জেনে নাও।", images: [result.image.src] },
  };
};

const ResultPage = async ({ params }) => {
  const { type } = await params;
  const result = getResult(type);
  if (!result) notFound();

  return (
    <div className="site-container px-5 sm:px-8 xl:px-0">
      <div className="grid items-center gap-10 pt-6 lg:grid-cols-[1fr_440px] lg:gap-16">
        <div>
          <p className="inline-block -rotate-2 bg-leaf px-4 py-1 font-display text-lg text-white">তোমার ফলাফল</p>
          <h1 className="mt-4 font-display text-[44px] leading-[1.15] font-extrabold text-leaf md:text-7xl">
            তুমি ছিলে <span className="brush">{result.title}!</span>
          </h1>
          <p className="mt-5 max-w-[560px] text-lg text-ink-2">{result.text}</p>

          <section aria-labelledby="traits" className="paper mt-8 px-5 py-6">
            <h2 id="traits" className="text-center font-display text-xl font-bold text-ink">তোমার ৪টি বিশেষ গুণ</h2>
            <ul className="mt-4 grid grid-cols-2 gap-y-5 md:grid-cols-4">
              {result.traits.map((trait) => (
                <li key={trait.id} className="flex flex-col items-center gap-2 px-2 text-center text-sm font-semibold text-ink-2 md:border-r md:border-dashed md:border-line md:last:border-0">
                  <span className="grid size-14 place-items-center rounded-full bg-marker/40 text-leaf">
                    <Icon name={trait.icon} className="size-7" />
                  </span>
                  {trait.label}
                </li>
              ))}
            </ul>
          </section>
        </div>

        <div>
          <article className="frame-rickshaw text-center">
            <div className="relative aspect-[4/3] overflow-hidden">
              <Image src={result.image} alt="" fill priority sizes="(max-width: 1024px) 80vw, 360px" placeholder="blur" className="object-cover" />
            </div>
            <p className="mt-3 text-sm text-ink-3">তোমার শৈশব পরিচয়পত্র</p>
            <p className="font-display text-3xl leading-tight font-extrabold text-brick">{result.title}</p>
            <p className="mt-1 pb-2 font-hand text-ink-blue">তুমি কী ছিলে? smritirbaksho.com/quiz</p>
          </article>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <ShareResult title={result.title} />
            <Button href="/card" variant="green">
              <IdCard aria-hidden="true" className="size-[18px]" />
              পুরো কার্ড তৈরি করুন
            </Button>
          </div>
          <Link href="/quiz" className="mx-auto mt-2 flex min-h-11 w-fit items-center gap-2 text-sm font-semibold text-ink-2 hover:text-leaf">
            <RotateCcw aria-hidden="true" className="size-4" />
            আবার খেলি
          </Link>
        </div>
      </div>

      <section aria-labelledby="others" className="mt-16">
        <SectionTitle id="others" flowers="left" className="text-2xl md:text-2xl">বাকিরা কী পেয়েছে</SectionTitle>
        <ul className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {results.map((item) => {
            const isMine = item.id === result.id;
            return (
              <li key={item.id}>
                <Link
                  href={`/quiz/result/${item.id}`}
                  aria-current={isMine ? "page" : undefined}
                  className={`flex h-full min-h-28 flex-col justify-between rounded-md p-5 shadow-[0_10px_22px_-16px_rgb(90_60_20/0.55)] ${isMine ? "bg-leaf text-white" : "paper"}`}
                >
                  <span className="font-display text-lg leading-snug font-bold">{item.title}</span>
                  <span className={`text-sm ${isMine ? "text-[#dfe9dc]" : "text-ink-3"}`}>
                    {toBn(resultShares[item.id])}%{isMine ? " · তুমি" : ""}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
};

export default ResultPage;
