import { Suspense } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Flower2 } from "lucide-react";
import CategoryTile from "@/components/stories/CategoryTile";
import StoryCard from "@/components/stories/StoryCard";
import FilterChips from "@/components/ui/FilterChips";
import Scrap from "@/components/ui/Scrap";
import Skeleton from "@/components/ui/Skeleton";
import { buttonClass } from "@/components/ui/Button";
import { divisions, getDivisionCounts, getStories, storyCategories } from "@/api/stories";
import { toBn } from "@/lib/utils/format";
import mapDivisions from "@/assets/images/map-divisions.jpg";

export const metadata = {
  title: "স্মৃতির ভাণ্ডার",
  description: "ছোট ছোট ঘটনা, বড় বড় অনুভূতি। খেলা, স্কুল, বৃষ্টি আর বন্ধুদের নিয়ে মানুষের শৈশবের গল্প পড়ুন।",
  alternates: { canonical: "/stories" },
};

const categoryChips = [{ id: "", label: "সব গল্প" }, ...storyCategories.map(({ id, label }) => ({ id, label }))];

const StoriesSkeleton = () => (
  <div role="status" aria-busy="true" className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
    <span className="sr-only">গল্পগুলো লোড হচ্ছে</span>
    {["s1", "s2", "s3", "s4"].map((id) => (
      <Skeleton key={id} className="aspect-[4/5]" />
    ))}
  </div>
);

const StoryResults = async ({ searchParams }) => {
  const { cat = "", division = "" } = await searchParams;
  const category = storyCategories.some((item) => item.id === cat) ? cat : "";
  const area = divisions.some((item) => item.id === division) ? division : "";
  const stories = await getStories({ category, division: area });
  const [featured, ...rest] = stories;
  const areaLabel = divisions.find((item) => item.id === area)?.label;

  const hrefFor = (id) => {
    const params = new URLSearchParams();
    if (id) params.set("cat", id);
    if (area) params.set("division", area);
    const search = params.toString();
    return search ? `/stories?${search}` : "/stories";
  };

  return (
    <>
      <div className="mt-6">
        <FilterChips label="গল্পের বিষয়" items={categoryChips} active={category} hrefFor={hrefFor} />
      </div>
      {areaLabel && (
        <p className="mt-3 text-[15px] text-ink-2">
          {areaLabel} বিভাগের গল্প দেখাচ্ছে ·{" "}
          <Link href={category ? `/stories?cat=${category}` : "/stories"} scroll={false} className="font-semibold text-leaf underline underline-offset-4">
            সব বিভাগ
          </Link>
        </p>
      )}

      {!featured ? (
        <div className="paper mt-6 px-6 py-12 text-center">
          <p className="font-display text-2xl font-bold text-leaf">এখানে এখনো কোনো গল্প নেই</p>
          <p className="mt-1 text-ink-2">প্রথম গল্পটা হয়তো আপনারই হবে। আপাতত অন্য বিষয়গুলো ঘুরে দেখুন।</p>
          <Link href="/stories" className="mt-4 inline-flex min-h-11 items-center font-semibold text-leaf underline underline-offset-4">
            সব গল্প দেখুন
          </Link>
        </div>
      ) : (
        <>
          <article className="paper relative mt-6 grid items-center gap-6 p-4 md:grid-cols-[300px_1fr] md:p-6">
            <div className="relative aspect-[4/3] -rotate-2 overflow-hidden bg-[#fbf8f0] p-2 shadow-[0_10px_24px_-10px_rgb(60_40_10/0.5)]">
              <div className="relative size-full">
                <Image src={featured.image} alt={featured.title} fill sizes="(max-width: 768px) 90vw, 300px" placeholder="blur" className="object-cover" />
              </div>
            </div>
            <div className="md:pr-44">
              <p className="inline-block -rotate-2 bg-brick px-3 py-0.5 text-sm font-semibold text-white">ফিচার্ড স্টোরি</p>
              <h2 className="mt-2.5 font-display text-2xl leading-snug font-bold text-leaf md:text-3xl">{featured.title}</h2>
              <p className="mt-2 text-ink-2">{featured.excerpt}</p>
              <Link href={`/stories/${featured.slug}`} className={buttonClass({ variant: "green", size: "sm", className: "mt-4" })}>
                সম্পূর্ণ পড়ুন
                <ArrowRight aria-hidden="true" className="size-4" />
              </Link>
            </div>
            <Scrap className="absolute top-8 right-6 hidden w-40 rotate-4 text-lg lg:block">ছোট ঘটনা, কিন্তু মনে থেকে গেছে সারাজীবন…</Scrap>
          </article>

          {rest.length > 0 && (
            <section aria-labelledby="latest" className="mt-12">
              <h2 id="latest" className="flex items-center gap-3 font-display text-2xl font-extrabold text-leaf">
                <Flower2 aria-hidden="true" className="size-5 text-brick" />
                নতুন স্মৃতিচারণ
              </h2>
              <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {rest.map((story) => (
                  <StoryCard key={story.slug} story={story} />
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </>
  );
};

const DivisionStrip = async () => {
  const counts = await getDivisionCounts();
  return (
    <section aria-labelledby="divisions" className="paper mt-12 grid items-center gap-6 p-5 md:grid-cols-[150px_1fr] md:p-7">
      <Image src={mapDivisions} alt="বাংলাদেশের আটটি বিভাগের মানচিত্র" className="mx-auto w-28 md:w-full" />
      <div>
        <h2 id="divisions" className="flex items-center gap-3 font-display text-2xl font-extrabold text-leaf">
          <Flower2 aria-hidden="true" className="size-5 text-brick" />
          বিভাগ অনুযায়ী গল্প
        </h2>
        <ul className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          {counts.map((division) => (
            <li key={division.id}>
              <Link
                href={`/stories?division=${division.id}`}
                scroll={false}
                className="flex min-h-12 items-center justify-between rounded-md border border-[#e2d3b2] bg-card px-3.5 text-[15px] font-semibold hover:border-leaf"
              >
                {division.label}
                <span className="text-xs font-normal text-ink-3">{toBn(division.count)}টি গল্প</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
};

const StoriesPage = ({ searchParams }) => {
  return (
    <div className="site-container px-5 sm:px-8 xl:px-0">
      <header className="pt-4 text-center">
        <h1 className="font-display text-[42px] leading-tight font-extrabold text-leaf md:text-6xl">
          <span className="brush">স্মৃতির ভাণ্ডার</span>
        </h1>
        <p className="mt-2 font-display text-xl font-bold text-ink md:text-2xl">ছোট ছোট ঘটনা, বড় বড় অনুভূতি</p>
        <p className="mt-1 text-ink-2">পড়ুন, শেয়ার করুন, আবার বাঁচুন আমাদের শৈশব।</p>
      </header>

      <div className="-mx-5 mt-8 grid auto-cols-[62%] grid-flow-col gap-3 overflow-x-auto px-5 pb-2 [scrollbar-width:none] sm:mx-0 sm:auto-cols-auto sm:grid-flow-row sm:grid-cols-3 sm:px-0 lg:grid-cols-5 lg:gap-[18px]">
        {storyCategories.map((category) => (
          <CategoryTile key={category.id} category={category} />
        ))}
      </div>

      <Suspense fallback={<StoriesSkeleton />}>
        <StoryResults searchParams={searchParams} />
      </Suspense>

      <DivisionStrip />
    </div>
  );
};

export default StoriesPage;
