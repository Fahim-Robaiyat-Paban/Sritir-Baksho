import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CalendarDays, Clock, Flag, House, Heart, MapPin, Sun } from "lucide-react";
import StoryActions from "@/components/stories/StoryActions";
import StoryCard from "@/components/stories/StoryCard";
import Scrap from "@/components/ui/Scrap";
import SectionTitle from "@/components/ui/SectionTitle";
import { getStory, getStoryCategoryLabel, getStorySlugs } from "@/api/stories";
import { toBn } from "@/lib/utils/format";

export const generateStaticParams = () => getStorySlugs().map((slug) => ({ slug }));

export const generateMetadata = async ({ params }) => {
  const { slug } = await params;
  const story = await getStory(slug);
  if (!story) return { title: "গল্প পাওয়া যায়নি" };
  return {
    title: story.title,
    description: story.excerpt,
    alternates: { canonical: `/stories/${slug}` },
    openGraph: { title: story.title, description: story.excerpt, type: "article", images: [story.image.src] },
  };
};

const StoryPage = async ({ params }) => {
  const { slug } = await params;
  const story = await getStory(slug);
  if (!story) notFound();

  const facts = [
    { id: "place", icon: MapPin, label: "স্থান", value: story.facts.place },
    { id: "years", icon: CalendarDays, label: "সময়", value: story.facts.years },
    { id: "games", icon: Flag, label: "খেলা", value: story.facts.games },
    { id: "season", icon: Sun, label: "মৌসুম", value: story.facts.season },
    { id: "author", icon: Heart, label: "লিখেছেন", value: story.author },
  ];

  return (
    <div className="site-container px-5 sm:px-8 xl:px-0">
      <nav aria-label="ব্রেডক্রাম্ব" className="flex flex-wrap items-center gap-x-2 text-sm text-ink-3">
        <Link href="/" className="inline-flex min-h-11 items-center gap-1 hover:text-leaf">
          <House aria-hidden="true" className="size-3.5" />
          হোম
        </Link>
        <span aria-hidden="true">›</span>
        <Link href="/stories" className="inline-flex min-h-11 items-center hover:text-leaf">স্মৃতিচারণ</Link>
        <span aria-hidden="true">›</span>
        <span className="text-ink-2">{story.title}</span>
      </nav>

      <div className="mt-2 grid items-start gap-8 lg:grid-cols-[1fr_300px]">
        <article>
          <p className="inline-block -rotate-2 bg-leaf px-3 py-0.5 text-sm font-semibold text-white">{getStoryCategoryLabel(story.category)}</p>
          <h1 className="mt-3 font-display text-[34px] leading-tight font-extrabold text-leaf md:text-5xl">
            <span className="brush">{story.title}</span>
          </h1>
          <p className="mt-3 flex items-center gap-2 text-sm text-ink-3">
            <Clock aria-hidden="true" className="size-4" />
            {story.date} · {toBn(story.readMins)} মিনিট পড়া
          </p>
          <p className="mt-4 text-lg leading-relaxed font-semibold text-ink">{story.excerpt}</p>

          <div className="relative mt-6 aspect-[16/9] overflow-hidden rounded-md shadow-[0_14px_30px_-18px_rgb(90_60_20/0.6)]">
            <Image src={story.image} alt={story.title} fill priority sizes="(max-width: 1024px) 92vw, 860px" placeholder="blur" className="object-cover" />
          </div>

          <div className="mt-7 max-w-[68ch] text-[17px] leading-[1.9] text-[#2b2f2a] md:text-lg">
            {story.body.map((paragraph) => (
              <p key={paragraph} className="mt-5 first:mt-0">{paragraph}</p>
            ))}
          </div>

          <StoryActions slug={story.slug} baseCount={story.reactions} />
        </article>

        <aside className="grid gap-6">
          <section aria-labelledby="story-facts" className="paper px-6 py-6">
            <h2 id="story-facts" className="font-display text-xl font-bold text-leaf">গল্পের কিছু কথা</h2>
            <dl className="mt-4 grid gap-3 text-[15px]">
              {facts.map(({ id, icon: Glyph, label, value }) => (
                <div key={id} className="grid grid-cols-[22px_70px_1fr] items-start gap-2">
                  <Glyph aria-hidden="true" className="mt-1 size-4 text-leaf" />
                  <dt className="text-ink-3">{label}:</dt>
                  <dd className="font-semibold">{value}</dd>
                </div>
              ))}
            </dl>
          </section>
          <Scrap className="relative mx-2 rotate-2 text-xl leading-normal">“{story.pullQuote}”</Scrap>
        </aside>
      </div>

      <section aria-labelledby="more-stories" className="mt-14">
        <div className="flex items-end justify-between gap-4">
          <SectionTitle id="more-stories" flowers="left" className="text-2xl md:text-2xl">আরও কিছু স্মৃতিচারণ</SectionTitle>
          <Link href="/stories" className="inline-flex min-h-11 items-center gap-1.5 text-sm font-semibold text-leaf">
            <ArrowLeft aria-hidden="true" className="size-4" />
            সব গল্পে ফিরে যান
          </Link>
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {story.more.map((item) => (
            <StoryCard key={item.slug} story={item} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default StoryPage;
