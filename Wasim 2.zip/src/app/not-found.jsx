import Button from "@/components/ui/Button";
import Scrap from "@/components/ui/Scrap";

const NotFound = () => {
  return (
    <div className="site-container px-5 pt-10 text-center sm:px-8 xl:px-0">
      <h1 className="font-display text-5xl leading-tight font-extrabold text-leaf md:text-7xl">
        <span className="brush">হারিয়ে গেছে!</span>
      </h1>
      <p className="mx-auto mt-4 max-w-md text-lg text-ink-2">এই পাতাটা খুঁজে পাওয়া গেল না। ঠিক লুকোচুরির মতো, কোথাও লুকিয়ে আছে হয়তো।</p>
      <Scrap className="mx-auto mt-6 w-fit -rotate-2">কেউ খুঁজে পাবে না… ☺</Scrap>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Button href="/">হোমে ফিরে যান</Button>
        <Button href="/games" variant="line">খেলাগুলো দেখুন</Button>
      </div>
    </div>
  );
};

export default NotFound;
