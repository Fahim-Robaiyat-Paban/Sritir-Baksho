import { Suspense } from "react";
import Link from "next/link";
import { ArrowRight, Box } from "lucide-react";
import IdCard from "@/components/card/IdCard";
import FilterChips from "@/components/ui/FilterChips";
import Skeleton from "@/components/ui/Skeleton";
import { buttonClass } from "@/components/ui/Button";
import { galleryEras, getGalleryCards } from "@/api/gallery";
import { cardFields } from "@/api/cardOptions";

export const metadata = {
  title: "সব শৈশব পরিচয়পত্র",
  description: "আমাদের সবার গল্প, একসাথে। ৮০, ৯০ আর ২০০০-এর দশকের মানুষদের বানানো শৈশব পরিচয়পত্রের গ্যালারি।",
  alternates: { canonical: "/gallery" },
};

const tilts = ["-rotate-1", "rotate-1", "-rotate-[0.5deg]", "rotate-[0.5deg]"];

const hrefFor = (id) => (id === "all" ? "/gallery" : `/gallery?era=${id}`);

const MakeYoursTile = () => (
  <div className="mb-5 break-inside-avoid rounded-md bg-leaf p-7 text-center text-[#f3ead3] [background-image:var(--grain)]">
    <Box aria-hidden="true" className="mx-auto size-11" />
    <p className="mt-3 font-display text-2xl font-extrabold text-white">আপনারটা বানান</p>
    <p className="mt-1 text-sm">আপনার শৈশব, আপনার গল্প। এখনই লিখুন!</p>
    <Link href="/card" className={buttonClass({ size: "sm", className: "mt-5" })}>
      শুরু করুন
      <ArrowRight aria-hidden="true" className="size-4" />
    </Link>
  </div>
);

const GallerySkeleton = () => (
  <div role="status" aria-busy="true" className="mt-7 columns-1 gap-5 sm:columns-2 lg:columns-3">
    <span className="sr-only">কার্ডগুলো লোড হচ্ছে</span>
    {["k1", "k2", "k3", "k4", "k5", "k6"].map((id) => (
      <Skeleton key={id} className="mb-5 h-[460px] break-inside-avoid" />
    ))}
  </div>
);

const GalleryGrid = async ({ searchParams }) => {
  const { era: rawEra } = await searchParams;
  const era = galleryEras.some((item) => item.id === rawEra) ? rawEra : "all";
  const cards = await getGalleryCards({ era });

  return (
    <>
      <div className="mt-7">
        <FilterChips label="দশক" items={galleryEras} active={era} hrefFor={hrefFor} />
      </div>
      {cards.length === 0 ? (
        <div className="paper mt-7 px-6 py-12 text-center">
          <p className="font-display text-2xl font-bold text-leaf">এই দশকের কোনো কার্ড এখনো নেই</p>
          <Link href="/card" className="mt-4 inline-flex min-h-11 items-center font-semibold text-leaf underline underline-offset-4">
            প্রথম কার্ডটা আপনিই বানান
          </Link>
        </div>
      ) : (
        <div className="mt-7 columns-1 gap-5 sm:columns-2 lg:columns-3">
          {cards.map((card, i) => (
            <div key={card.id} className={`mb-5 break-inside-avoid ${tilts[i % tilts.length]}`}>
              <IdCard card={card} fields={cardFields.slice(1)} compact />
            </div>
          ))}
          <MakeYoursTile />
        </div>
      )}
    </>
  );
};

const GalleryPage = ({ searchParams }) => {
  return (
    <div className="site-container px-5 sm:px-8 xl:px-0">
      <header className="pt-4 text-center">
        <h1 className="font-display text-[38px] leading-tight font-extrabold text-leaf md:text-6xl">
          সব <span className="brush">শৈশব পরিচয়পত্র</span>
        </h1>
        <p className="mt-2 text-lg text-ink-2">আমাদের সবার গল্প, একসাথে</p>
      </header>
      <Suspense fallback={<GallerySkeleton />}>
        <GalleryGrid searchParams={searchParams} />
      </Suspense>
    </div>
  );
};

export default GalleryPage;
