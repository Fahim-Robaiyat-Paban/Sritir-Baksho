import Link from "next/link";
import { Check } from "lucide-react";

export const metadata = {
  title: "গোপনীয়তা ও শর্তাবলী",
  description: "স্মৃতির বাক্স কী তথ্য রাখে, আপনার ছবি কোথায় যায়, কী প্রকাশ্য আর কীভাবে মুছে ফেলবেন।",
  alternates: { canonical: "/privacy" },
};

const sections = [
  { id: "collect", title: "কী তথ্য রাখি", body: ["কার্ড বা গল্প বানানোর সময় আপনি যা লেখেন (নাম, ডাকনাম, এলাকা, প্রিয় খেলা), শুধু সেটুকুই আমরা রাখি। যোগাযোগ ফর্মে ইমেইল দিলে সেটা শুধু আপনাকে উত্তর দিতে ব্যবহার হয়।"] },
  { id: "card", title: "আপনার কার্ড", body: ["কার্ডের ছবি আপনার ডিভাইসেই তৈরি হয়। আপনি যা টাইপ করেন, তা আপনার ব্রাউজারেই সেভ থাকে যাতে পাতা রিফ্রেশ করলেও হারিয়ে না যায়। গ্যালারিতে প্রকাশ না করলে কিছুই আমাদের সার্ভারে যায় না।"] },
  { id: "public", title: "কী প্রকাশ্য, কী না", body: ["গ্যালারিতে প্রকাশ করলে আপনার কার্ডে যা লেখা আছে সবাই দেখতে পাবে। প্রকাশের আগে আমরা প্রিভিউ দেখাই, আর যেকোনো সময় প্রকাশ বন্ধ করতে পারেন।"] },
  { id: "delete", title: "মুছে ফেলা", body: ["যেকোনো কার্ড বা গল্প মুছে ফেলতে hello@smritirbaksho.com-এ লিখুন। ৭ দিনের মধ্যে সব তথ্য স্থায়ীভাবে মুছে ফেলা হবে।"] },
];

const rules = [
  "শুধু নিজের স্মৃতি আর নিজের তোলা বা অনুমতি পাওয়া ছবি দিন।",
  "অন্য কারো ছবি বা পুরো নাম তাদের অনুমতি ছাড়া প্রকাশ করবেন না।",
  "কাউকে অপমান বা হেয় করে এমন কিছু লিখবেন না।",
];

const summary = ["কার্ড বানাতে কোনো অ্যাকাউন্ট লাগে না।", "আপনি না চাইলে আপনার কার্ড কেউ দেখবে না।", "আমরা আপনার তথ্য কারো কাছে বিক্রি করি না।"];

const PrivacyPage = () => {
  return (
    <div className="site-container grid gap-10 px-5 pt-6 sm:px-8 lg:grid-cols-[200px_minmax(0,1fr)] lg:gap-20 xl:px-0">
      <nav aria-label="এই পাতায়" className="hidden self-start lg:sticky lg:top-6 lg:block">
        <p className="mb-3 text-sm font-semibold text-ink-3">এই পাতায়</p>
        {[...sections, { id: "terms", title: "ব্যবহারের নিয়ম" }].map((section) => (
          <a key={section.id} href={`#${section.id}`} className="flex min-h-10 items-center text-[15px] text-ink-2 hover:text-leaf">
            {section.title}
          </a>
        ))}
      </nav>

      <article className="paper max-w-[760px] px-6 py-8 md:px-10 md:py-10">
        <h1 className="font-display text-[38px] leading-tight font-extrabold text-leaf md:text-5xl">
          <span className="brush">গোপনীয়তা ও শর্তাবলী</span>
        </h1>
        <p className="mt-3 text-sm text-ink-3">সর্বশেষ হালনাগাদ: ১ জানুয়ারি ২০২৫</p>

        <section aria-labelledby="summary" className="mt-8 rounded-md bg-leaf-soft/60 px-5 py-5">
          <h2 id="summary" className="font-display text-xl font-bold text-leaf">সংক্ষেপে</h2>
          <ul className="mt-3 grid gap-2.5">
            {summary.map((item) => (
              <li key={item} className="flex gap-3">
                <Check aria-hidden="true" className="mt-1 size-5 shrink-0 text-leaf" />
                {item}
              </li>
            ))}
          </ul>
        </section>

        {sections.map((section) => (
          <section key={section.id} aria-labelledby={section.id}>
            <h2 id={section.id} className="mt-10 scroll-mt-6 font-display text-2xl font-bold text-leaf md:text-[28px]">{section.title}</h2>
            {section.body.map((paragraph) => (
              <p key={paragraph} className="mt-3 text-[17px] leading-[1.85] text-[#2b2f2a]">{paragraph}</p>
            ))}
          </section>
        ))}

        <section aria-labelledby="terms">
          <h2 id="terms" className="mt-10 scroll-mt-6 font-display text-2xl font-bold text-leaf md:text-[28px]">ব্যবহারের নিয়ম</h2>
          <p className="mt-3 text-[17px] leading-[1.85] text-[#2b2f2a]">স্মৃতির বাক্স সবার জন্য একটা আনন্দের জায়গা। তাই কয়েকটা সহজ নিয়ম:</p>
          <ul className="mt-2 list-disc pl-6 text-[17px] leading-[1.85] text-[#2b2f2a]">
            {rules.map((rule) => (
              <li key={rule}>{rule}</li>
            ))}
          </ul>
          <p className="mt-3 text-[17px] leading-[1.85] text-[#2b2f2a]">
            নিয়ম ভাঙলে আমরা সেই কন্টেন্ট সরিয়ে দিতে পারি। কোনো প্রশ্ন থাকলে{" "}
            <Link href="/about#contact" className="font-semibold text-leaf underline underline-offset-4">যোগাযোগ করুন</Link>।
          </p>
        </section>
      </article>
    </div>
  );
};

export default PrivacyPage;
