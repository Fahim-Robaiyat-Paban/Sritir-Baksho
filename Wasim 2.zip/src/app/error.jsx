"use client";
import { useEffect } from "react";
import Button from "@/components/ui/Button";

const ErrorPage = ({ error, reset }) => {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="site-container px-5 pt-10 text-center sm:px-8 xl:px-0">
      <h1 className="font-display text-4xl font-extrabold text-leaf md:text-5xl">কিছু একটা গোলমাল হয়েছে</h1>
      <p className="mx-auto mt-3 max-w-md text-ink-2">পাতাটা লোড করা গেল না। একটু পরে আবার চেষ্টা করুন।</p>
      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <Button onClick={reset}>আবার চেষ্টা করুন</Button>
        <Button href="/" variant="line">হোমে ফিরে যান</Button>
      </div>
    </div>
  );
};

export default ErrorPage;
