import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { ArrowLeft, Lightbulb, MapPin } from "lucide-react";
import AddToCardButton from "@/components/games/AddToCardButton";
import GameThumb from "@/components/games/GameThumb";
import SectionTitle from "@/components/ui/SectionTitle";
import { getCategoryLabel, getGame, getGameSlugs } from "@/api/games";
import { toBn } from "@/lib/utils/format";

export const generateStaticParams = () => getGameSlugs().map((slug) => ({ slug }));

export const generateMetadata = async ({ params }) => {
  const { slug } = await params;
  const game = await getGame(slug);
  if (!game) return { title: "খেলা পাওয়া যায়নি" };
  return {
    title: `${game.name} খেলার নিয়ম`,
    description: game.intro,
    alternates: { canonical: `/games/${slug}` },
    openGraph: { title: game.name, description: game.line, images: [game.image.src] },
  };
};

const sections = [
  { id: "how", label: "কিভাবে খেলবেন" },
  { id: "names", label: "আঞ্চলিক নাম" },
  { id: "facts", label: "মজার তথ্য" },
  { id: "related", label: "সম্পর্কিত খেলা" },
];

const GamePage = async ({ params }) => {
  const { slug } = await params;
  const game = await getGame(slug);
  if (!game) notFound();

  const info = [
    { id: "players", label: "খেলোয়াড়", value: game.players },
    { id: "place", label: "জায়গা", value: game.place },
    { id: "duration", label: "সময়", value: game.duration },
    { id: "gear", label: "সরঞ্জাম", value: game.gear },
    { id: "season", label: "বেশি খেলা হতো", value: game.season },
  ];

  return (
    <div className="site-container px-5 sm:px-8 xl:px-0">
      <Link href="/games" className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-ink-2 hover:text-leaf">
        <ArrowLeft aria-hidden="true" className="size-4" />
        খেলার লাইব্রেরিতে ফিরে যান
      </Link>

      <header className="paper mt-1 grid items-center gap-6 px-6 py-8 md:grid-cols-[1fr_320px] md:px-10">
        <div>
          <p className="inline-block -rotate-2 bg-leaf px-3 py-0.5 text-sm font-semibold text-white">{getCategoryLabel(game.category)}</p>
          <h1 className="mt-3 font-display text-5xl leading-tight font-extrabold text-white md:text-7xl">
            <span className="brush [--brush-color:var(--color-leaf)]">{game.name}</span>
          </h1>
          <p className="mt-3 text-lg text-ink-2">{game.line}</p>
        </div>
        <figure className="relative rotate-2 bg-[#fbf8f0] p-2 pb-5 shadow-[0_10px_24px_-10px_rgb(60_40_10/0.5)]">
          <div className="relative aspect-[16/10] overflow-hidden">
            <Image src={game.image} alt={game.name} fill priority sizes="(max-width: 768px) 90vw, 320px" placeholder="blur" className="object-cover" />
          </div>
        </figure>
      </header>

      <nav aria-label="এই পাতায়" className="-mx-5 mt-6 flex gap-2.5 overflow-x-auto px-5 [scrollbar-width:none] sm:mx-0 sm:px-0">
        {sections.map((section, i) => (
          <a
            key={section.id}
            href={`#${section.id}`}
            className={`inline-flex h-11 shrink-0 items-center rounded-full border-[1.5px] px-5 text-[15px] font-semibold ${i === 0 ? "border-leaf bg-leaf text-white" : "border-[#cdbb95] text-ink-2 hover:border-leaf hover:text-leaf"}`}
          >
            {section.label}
          </a>
        ))}
      </nav>

      <div className="mt-6 grid items-start gap-6 lg:grid-cols-[1fr_300px]">
        <article className="paper px-6 py-7 md:px-9">
          <p className="text-lg leading-relaxed text-ink-2">{game.intro}</p>

          <SectionTitle id="how" flowers="left" className="mt-8 scroll-mt-6 text-2xl md:text-2xl">
            কিভাবে খেলবেন
          </SectionTitle>
          <ol className="mt-4 grid gap-3.5">
            {game.steps.map((step, i) => (
              <li key={step} className="grid grid-cols-[32px_1fr] gap-3 text-base leading-relaxed md:text-[17px]">
                <span aria-hidden="true" className="grid size-8 place-items-center rounded-full bg-brick font-bold text-white">{toBn(i + 1)}</span>
                {step}
              </li>
            ))}
          </ol>

          {game.slug === "gollachut" && (
            <figure className="mt-8">
              <figcaption className="mb-2 font-display text-lg font-bold text-ink">খেলার মাঠের গঠন (উপর থেকে দেখা)</figcaption>
              <div className="relative aspect-[382/210] overflow-hidden rounded">
                <Image src={game.image} alt="চক দিয়ে আঁকা গোল্লাছুটের মাঠ, দুই দলের ঘর আর মাঝে গোল্লা" fill sizes="(max-width: 1024px) 90vw, 760px" className="object-cover" />
              </div>
            </figure>
          )}
        </article>

        <aside className="grid gap-5">
          <div className="paper px-6 py-6">
            <dl className="grid gap-3 text-[15px]">
              {info.map((item) => (
                <div key={item.id} className="flex justify-between gap-4 border-b border-dashed border-line pb-2.5">
                  <dt className="text-ink-3">{item.label}</dt>
                  <dd className="text-right font-semibold">{item.value}</dd>
                </div>
              ))}
            </dl>
            <div className="mt-5">
              <AddToCardButton gameName={game.name} />
            </div>
          </div>

          <section aria-labelledby="names" className="paper scroll-mt-6 px-6 py-6">
            <h2 id="names" className="flex items-center gap-2 font-display text-xl font-bold text-leaf">
              <MapPin aria-hidden="true" className="size-5" />
              আঞ্চলিক নাম
            </h2>
            <ul className="mt-3 grid gap-2 text-[15px]">
              {game.regionalNames.map((name) => (
                <li key={name.id}>
                  <b className="font-semibold">{name.name}</b> <span className="text-ink-3">({name.region})</span>
                </li>
              ))}
            </ul>
          </section>

          <section aria-labelledby="facts" className="scroll-mt-6 rounded bg-[#f3dc9a] px-6 py-6 shadow-[0_14px_30px_-18px_rgb(90_60_20/0.45)] [background-image:var(--grain)]">
            <h2 id="facts" className="flex items-center gap-2 font-display text-xl font-bold text-leaf">
              <Lightbulb aria-hidden="true" className="size-5" />
              মজার তথ্য
            </h2>
            <ul className="mt-3 grid list-disc gap-2 pl-5 text-[15px]">
              {game.facts.map((fact) => (
                <li key={fact}>{fact}</li>
              ))}
            </ul>
          </section>
        </aside>
      </div>

      <section aria-labelledby="related" className="mt-12">
        <SectionTitle id="related" flowers="left" className="text-2xl md:text-2xl">
          সম্পর্কিত খেলা
        </SectionTitle>
        <div className="mt-5 grid grid-cols-3 gap-3 md:grid-cols-5 md:gap-4">
          {game.related.map((item) => (
            <GameThumb key={item.slug} game={item} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default GamePage;
