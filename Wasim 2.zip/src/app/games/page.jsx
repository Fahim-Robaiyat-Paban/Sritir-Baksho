import { Suspense } from "react";
import Link from "next/link";
import FilterChips from "@/components/ui/FilterChips";
import Polaroid from "@/components/ui/Polaroid";
import GameCard from "@/components/games/GameCard";
import GameSearch from "@/components/games/GameSearch";
import GamesSkeleton, { GameGridSkeleton } from "@/components/games/GamesSkeleton";
import { gameCategories, getGames } from "@/api/games";
import gameMarbles from "@/assets/images/game-marbles.jpg";

export const metadata = {
  title: "খেলার লাইব্রেরি",
  description: "গোল্লাছুট, লাটিম, গুটি, ঘুড়ি থেকে কাগজের নৌকা, বাংলার ঐতিহ্যবাহী শৈশবের খেলাগুলোর নিয়ম আর গল্প।",
  alternates: { canonical: "/games" },
};

const hrefFor = (q) => (id) => {
  const params = new URLSearchParams();
  if (id !== "all") params.set("cat", id);
  if (q) params.set("q", q);
  const search = params.toString();
  return search ? `/games?${search}` : "/games";
};

const GameGrid = async ({ category, q }) => {
  const games = await getGames({ category, q });

  if (games.length === 0) {
    return (
      <div className="paper mt-6 px-6 py-12 text-center">
        <p className="font-display text-2xl font-bold text-leaf">এই নামে কোনো খেলা পাওয়া যায়নি</p>
        <p className="mt-1 text-ink-2">বানানটা আরেকবার দেখুন, বা সব খেলা থেকে খুঁজুন।</p>
        <Link href="/games" className="mt-4 inline-flex min-h-11 items-center font-semibold text-leaf underline underline-offset-4">
          সব খেলা দেখুন
        </Link>
      </div>
    );
  }

  return (
    <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-5 lg:grid-cols-4">
      {games.map((game) => (
        <GameCard key={game.slug} game={game} />
      ))}
    </div>
  );
};

const GameResults = async ({ searchParams }) => {
  const { cat, q = "" } = await searchParams;
  const category = gameCategories.some((item) => item.id === cat) ? cat : "all";

  return (
    <>
      <div className="mt-7">
        <FilterChips label="খেলার ধরন" items={gameCategories} active={category} hrefFor={hrefFor(q)} />
      </div>
      <div className="mt-4">
        <GameSearch key={category} category={category} initialQuery={q} />
      </div>
      <Suspense key={`${category}-${q}`} fallback={<GameGridSkeleton />}>
        <GameGrid category={category} q={q} />
      </Suspense>
    </>
  );
};

const GamesPage = ({ searchParams }) => {
  return (
    <div className="site-container px-5 sm:px-8 xl:px-0">
      <header className="paper relative grid items-center gap-6 overflow-hidden px-6 py-8 md:grid-cols-[1fr_300px] md:px-10">
        <div>
          <p className="font-display text-lg font-bold text-leaf">ঐতিহ্যের খেলা, আজও প্রাণে</p>
          <h1 className="mt-1 font-display text-[42px] leading-tight font-extrabold text-leaf md:text-6xl">
            <span className="brush">খেলার লাইব্রেরি</span>
          </h1>
          <p className="mt-3 max-w-md text-ink-2 md:text-lg">যে খেলাগুলো আমাদের শৈশবকে রঙিন করেছে, নিয়ম আর গল্পসহ এক জায়গায়।</p>
        </div>
        <div className="relative hidden md:block">
          <Polaroid image={gameMarbles} alt="মাটিতে কাচের মার্বেল" sizes="260px" className="w-[250px] rotate-3" priority />
          <p className="absolute -right-2 -bottom-4 w-28 -rotate-6 bg-marker/90 p-2.5 font-hand text-[15px] leading-snug text-ink">খেলাধুলা মানেই শৈশব</p>
        </div>
      </header>

      <Suspense fallback={<GamesSkeleton />}>
        <GameResults searchParams={searchParams} />
      </Suspense>
    </div>
  );
};

export default GamesPage;
