import Image from "next/image";
import { BookOpen, Box, IdCard, Images, Mail, MapPin, PenLine } from "lucide-react";
import ContactForm from "@/components/about/ContactForm";
import Reveal from "@/components/ui/Reveal";
import SectionTitle from "@/components/ui/SectionTitle";
import aboutSchool from "@/assets/images/about-school.jpg";

export const metadata = {
  title: "আমাদের কথা",
  description: "স্মৃতির বাক্স ৮০, ৯০ আর ২০০০-এর দশকে বড় হওয়া বাংলাদেশিদের নস্টালজিয়া কমিউনিটি। কেন বানালাম, কীভাবে কাজ করে, আর কীভাবে যোগাযোগ করবেন।",
  alternates: { canonical: "/about" },
};

// TODO: replace with live counts from the backend
const stats = [
  { id: "games", icon: BookOpen, value: "১২০+", label: "ঐতিহ্যবাহী খেলা" },
  { id: "stories", icon: PenLine, value: "৫০০০+", label: "স্মৃতির গল্প" },
  { id: "cards", icon: IdCard, value: "১০,০০০+", label: "শৈশব পরিচয়পত্র" },
];

const steps = [
  { id: "write", icon: PenLine, title: "আপনার শৈশব লিখুন", text: "নাম, এলাকা, বন্ধু, খেলা, খাবার আর সময়, কয়েকটা তথ্য দিন।" },
  { id: "card", icon: IdCard, title: "আপনার কার্ড পান", text: "মুহূর্তেই তৈরি হবে আপনার শৈশব পরিচয়পত্র, শেয়ার করার জন্য প্রস্তুত।" },
  { id: "join", icon: Images, title: "যোগ দিন কমিউনিটিতে", text: "গল্প লিখুন, অন্যদের কার্ড দেখুন, খেলাগুলো মনে করুন।" },
];

const AboutPage = () => {
  return (
    <div className="site-container px-5 sm:px-8 xl:px-0">
      <section className="grid items-center gap-8 pt-6 lg:grid-cols-[1fr_440px] lg:gap-14">
        <div>
          <h1 className="font-display text-[38px] leading-[1.2] font-extrabold text-leaf md:text-6xl">
            শৈশব শুধু একটা সময় না,
            <br />
            <span className="brush">এটা এক অনুভূতি!</span>
          </h1>
          <p className="mt-5 max-w-[560px] text-lg leading-relaxed text-ink-2">
            স্মৃতির বাক্স হলো ৮০, ৯০ আর ২০০০-এর দশকে বড় হওয়া বাংলাদেশের মানুষদের জন্য এক নস্টালজিয়া কমিউনিটি, যেখানে আমরা ফিরে যাই আমাদের শৈশবের গলি, খেলা, স্কুল, খাবার, বৃষ্টি আর সেই নির্ভেজাল দিনগুলোতে।
          </p>
        </div>
        <figure className="rotate-2 bg-[#fbf8f0] p-2.5 pb-6 shadow-[0_14px_30px_-14px_rgb(60_40_10/0.5)]">
          <div className="relative aspect-[200/172] overflow-hidden">
            <Image src={aboutSchool} alt="সূর্যাস্তে খালি স্কুল মাঠ" fill priority sizes="(max-width: 1024px) 90vw, 440px" placeholder="blur" className="object-cover" />
          </div>
        </figure>
      </section>

      <Reveal as="section" className="paper mt-14 grid gap-8 p-6 md:p-9 lg:grid-cols-[1fr_auto]">
        <div className="max-w-[560px]">
          <SectionTitle flowers="left" className="text-2xl md:text-3xl">কেন স্মৃতির বাক্স?</SectionTitle>
          <p className="mt-4 text-[17px] leading-relaxed text-ink-2">
            আজকের শিশুরা মার্বেল চেনে না, ডাংগুলির নিয়ম জানে না। যারা জানে, তারা এখন শহরের অফিসে, প্রবাসে, ব্যস্ত জীবনে। কিন্তু একটা ছবি, একটা ডাকনাম শুনলেই মনে পড়ে যায় পুরো একটা বিকেল। এই প্ল্যাটফর্মে আপনি পাবেন আপনার মতো মানুষদের গল্প, খেলাধুলার কথা আর পুরনো দিনের স্বাদ, সব এক জায়গায়।
          </p>
        </div>
        <dl className="grid grid-cols-3 divide-x divide-dashed divide-line self-center">
          {stats.map(({ id, icon: Glyph, value, label }) => (
            <div key={id} className="flex flex-col items-center px-3 text-center md:px-6">
              <Glyph aria-hidden="true" className="size-8 text-leaf" />
              <dt className="order-last text-sm text-ink-2">{label}</dt>
              <dd className="mt-2 font-display text-3xl font-extrabold text-brick md:text-4xl">{value}</dd>
            </div>
          ))}
        </dl>
      </Reveal>

      <Reveal as="section" className="mt-14">
        <SectionTitle flowers="left" className="text-2xl md:text-3xl">কীভাবে কাজ করে?</SectionTitle>
        <ol className="mt-6 grid gap-5 md:grid-cols-3">
          {steps.map(({ id, icon: Glyph, title, text }) => (
            <li key={id} className="paper torn px-6 pt-7 pb-9 text-center">
              <Glyph aria-hidden="true" className="mx-auto size-10 text-leaf" />
              <h3 className="mt-3 font-display text-xl font-bold text-ink">{title}</h3>
              <p className="mt-1.5 text-[15px] text-ink-2">{text}</p>
            </li>
          ))}
        </ol>
      </Reveal>

      <section id="contact" aria-labelledby="contact-title" className="mt-14 grid scroll-mt-6 gap-8 rounded-md bg-leaf p-6 text-[#f3ead3] [background-image:var(--grain)] md:p-9 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <h2 id="contact-title" className="flex items-center gap-3 font-display text-3xl font-extrabold text-white">
            <Box aria-hidden="true" className="size-8" />
            যোগাযোগ করুন
          </h2>
          <p className="mt-3 text-[#e8dcc0]">কোনো প্রশ্ন, পরামর্শ বা গল্প শেয়ার করতে চান? আমাদের লিখুন। আমরা আপনার কথা শুনতে চাই।</p>
          <ul className="mt-6 grid gap-3 text-[15px]">
            <li className="flex items-center gap-3">
              <Mail aria-hidden="true" className="size-5 text-marker" />
              <a href="mailto:hello@smritirbaksho.com" className="underline-offset-4 hover:underline">hello@smritirbaksho.com</a>
            </li>
            <li className="flex items-center gap-3">
              <MapPin aria-hidden="true" className="size-5 text-marker" />
              ঢাকা, বাংলাদেশ
            </li>
          </ul>
        </div>
        <ContactForm />
      </section>
    </div>
  );
};

export default AboutPage;
