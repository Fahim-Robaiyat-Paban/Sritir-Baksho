import Link from "next/link";

// Filters live in the URL, so each chip is just a link to the filtered view
const FilterChips = ({ items, active, hrefFor, label }) => {
  return (
    <nav aria-label={label} className="-mx-5 flex gap-2.5 overflow-x-auto px-5 pb-1 [scrollbar-width:none] sm:mx-0 sm:flex-wrap sm:px-0">
      {items.map((item) => {
        const isActive = item.id === active;
        return (
          <Link
            key={item.id}
            href={hrefFor(item.id)}
            scroll={false}
            aria-current={isActive ? "page" : undefined}
            className={`inline-flex h-11 shrink-0 items-center rounded-full border-[1.5px] px-5 text-[15px] font-semibold whitespace-nowrap transition-colors ${
              isActive ? "border-leaf bg-leaf text-white" : "border-[#cdbb95] bg-card/60 text-ink-2 hover:border-leaf hover:text-leaf"
            }`}
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
};

export default FilterChips;
