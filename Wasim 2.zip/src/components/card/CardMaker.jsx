"use client";
import { useRef, useState } from "react";
import Image from "next/image";
import { toBlob } from "html-to-image";
import { Download, IdCard as IdCardIcon, MapPin, Heart, Quote, RotateCcw, Share2, Tag } from "lucide-react";
import IdCard from "@/components/card/IdCard";
import Button from "@/components/ui/Button";
import Scrap from "@/components/ui/Scrap";
import { cardInks, cardObjects, cardThemes } from "@/api/cardOptions";
import { useCardStore } from "@/lib/store/useCardStore";
import { useRehydrate } from "@/lib/store/useRehydrate";
import { toBn } from "@/lib/utils/format";

const steps = [
  { id: "who", title: "আপনি কে ছিলেন?", hint: "আপনার নাম, ডাকনাম ও এলাকা লিখুন।" },
  { id: "para", title: "আপনার পাড়া", hint: "সবচেয়ে কাছের বন্ধুদের নাম দিন।" },
  { id: "likes", title: "আপনার পছন্দের জিনিসগুলো", hint: "খেলা, খাবার, দিনের প্রিয় সময়।" },
  { id: "line", title: "এক লাইনে বলুন", hint: "আপনার শৈশবকে নিয়ে একটি লাইন লিখুন।" },
];

const themeSwatches = {
  notebook: "bg-[linear-gradient(90deg,transparent_10px,#e9a3a0_10px_11px,transparent_11px),repeating-linear-gradient(#fbf8f0_0_7px,#bcd0e8_7px_8px)]",
  rickshaw: "bg-[url('/decor/frame-rickshaw.jpg')] bg-cover bg-center",
  postcard: "bg-[radial-gradient(circle_at_30%_20%,#f2e3c0,#d9c08e)]",
};

const Field = ({ id, label, icon: Glyph, value, onChange, placeholder, required = false, invalid = false }) => (
  <div>
    <label htmlFor={id} className="sr-only">{label}</label>
    <div className={`flex h-12 items-center gap-3 rounded-[10px] border-[1.5px] bg-[#fbf6ea] px-4 focus-within:border-leaf ${invalid ? "border-brick" : "border-[#d6c59f]"}`}>
      {Glyph && <Glyph aria-hidden="true" className="size-[18px] shrink-0 text-leaf" />}
      <input
        id={id}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        maxLength={60}
        required={required}
        aria-invalid={invalid || undefined}
        className="w-full bg-transparent text-[15px] outline-none placeholder:text-ink-3"
      />
    </div>
  </div>
);

const Step = ({ index, step, children }) => (
  <section aria-labelledby={`step-${step.id}`} className="mt-6 grid grid-cols-[34px_minmax(0,1fr)] gap-x-3 gap-y-2">
    <span aria-hidden="true" className="grid size-8 place-items-center rounded-full bg-brick font-bold text-white">{toBn(index + 1)}</span>
    <div>
      <h2 id={`step-${step.id}`} className="font-display text-xl leading-snug font-bold text-leaf">{step.title}</h2>
      <p className="text-[13px] text-ink-3">{step.hint}</p>
    </div>
    <div className="col-start-2 grid gap-2">{children}</div>
  </section>
);

const CardMaker = () => {
  useRehydrate(useCardStore);
  const card = useCardStore((state) => state.card);
  const setField = useCardStore((state) => state.setField);
  const reset = useCardStore((state) => state.reset);
  const cardRef = useRef(null);
  const [status, setStatus] = useState({ type: "idle", message: "" });
  const [showErrors, setShowErrors] = useState(false);

  const missingName = !card.name.trim();

  const renderImage = async () => {
    // Fonts must be ready, otherwise the PNG falls back to system Bangla glyphs
    await document.fonts.ready;
    return toBlob(cardRef.current, { pixelRatio: 2, cacheBust: true, backgroundColor: "#f1e6cc" });
  };

  const guard = () => {
    if (!missingName) return true;
    setShowErrors(true);
    setStatus({ type: "error", message: "কার্ড বানাতে অন্তত আপনার নামটা লিখুন।" });
    document.getElementById("card-name")?.focus();
    return false;
  };

  const handleDownload = async () => {
    if (!guard()) return;
    setStatus({ type: "busy", message: "ছবি তৈরি হচ্ছে…" });
    try {
      const blob = await renderImage();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "shoishob-porichoypotro.png";
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setStatus({ type: "done", message: "কার্ডটা ডাউনলোড হয়েছে। এবার শেয়ার করে বন্ধুদের ট্যাগ করুন!" });
    } catch (error) {
      console.error(error);
      setStatus({ type: "error", message: "ছবিটা তৈরি করা গেল না। আরেকবার চেষ্টা করুন।" });
    }
  };

  const handleShare = async () => {
    if (!guard()) return;
    setStatus({ type: "busy", message: "শেয়ারের জন্য তৈরি হচ্ছে…" });
    try {
      const blob = await renderImage();
      const file = new File([blob], "shoishob-porichoypotro.png", { type: "image/png" });
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: "আমার শৈশব পরিচয়পত্র", text: "তুমি কেমন ছিলে? বানাও তোমারটাও!" });
        setStatus({ type: "idle", message: "" });
        return;
      }
      await navigator.clipboard.writeText(`${window.location.origin}/card`);
      setStatus({ type: "done", message: "এই ব্রাউজারে সরাসরি শেয়ার হয় না, তাই লিংকটা কপি করা হয়েছে। ছবির জন্য ডাউনলোড করুন।" });
    } catch (error) {
      if (error?.name === "AbortError") {
        setStatus({ type: "idle", message: "" });
        return;
      }
      console.error(error);
      setStatus({ type: "error", message: "শেয়ার করা গেল না। ডাউনলোড করে শেয়ার করুন।" });
    }
  };

  const handleReset = () => {
    reset();
    setShowErrors(false);
    setStatus({ type: "idle", message: "" });
  };

  return (
    <div className="site-container mt-2 grid items-start gap-5 px-5 sm:px-8 lg:grid-cols-2 lg:gap-7 xl:grid-cols-[minmax(0,420px)_minmax(0,1fr)_minmax(0,280px)] xl:px-0">
      {/* Form */}
      <form onSubmit={(event) => event.preventDefault()} className="paper torn relative order-2 py-7 pr-5 pl-11 md:pr-8 md:pl-[52px] lg:order-none">
        <div aria-hidden="true" className="absolute top-6 bottom-6 left-2.5 w-3.5 bg-[radial-gradient(circle,var(--color-paper-2)_5px,rgb(0_0_0/0.12)_6px,transparent_7px)] bg-[length:14px_28px] md:left-3.5" />
        <h1 className="font-display text-2xl leading-snug font-extrabold text-leaf md:text-3xl">
          তৈরি করুন আপনার
          <br />
          <span className="brush mt-0.5 text-[28px] md:text-4xl">শৈশব পরিচয়পত্র</span>
        </h1>
        <p className="mt-1.5 text-[15px] text-ink-2">কয়েকটি সহজ ধাপে আপনার শৈশবকে ফিরে পান।</p>

        <Step index={0} step={steps[0]}>
          <Field id="card-name" label="আপনার নাম" icon={IdCardIcon} value={card.name} onChange={(v) => setField("name", v)} placeholder="আপনার নাম" required invalid={showErrors && missingName} />
          <Field id="card-nick" label="ডাকনাম" icon={Tag} value={card.nick} onChange={(v) => setField("nick", v)} placeholder="ডাকনাম (যদি থাকে)" />
          <Field id="card-area" label="এলাকা" icon={MapPin} value={card.area} onChange={(v) => setField("area", v)} placeholder="আপনার এলাকা, যেমন: মিরপুর, ঢাকা" />
          <p id="object-label" className="mt-1 text-[13px] font-semibold text-ink-2">আপনার ছোটবেলার জিনিসটি বেছে নিন</p>
          <div role="radiogroup" aria-labelledby="object-label" className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]">
            {cardObjects.map((object) => {
              const selected = card.object === object.id;
              return (
                <button
                  key={object.id}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  aria-label={object.label}
                  onClick={() => setField("object", object.id)}
                  className={`relative h-[54px] w-[62px] shrink-0 overflow-hidden rounded-lg border-2 ${selected ? "border-brick ring-2 ring-[#f6d6d2]" : "border-[#e2d3b2]"}`}
                >
                  <Image src={object.image} alt="" fill sizes="62px" className="object-cover" />
                </button>
              );
            })}
          </div>
        </Step>

        <Step index={1} step={steps[1]}>
          <Field id="card-friends" label="বন্ধুদের নাম" icon={Heart} value={card.friends} onChange={(v) => setField("friends", v)} placeholder="যেমন: রাকিব, সিয়াম" />
        </Step>

        <Step index={2} step={steps[2]}>
          <div className="grid gap-2">
            <Field id="card-game" label="প্রিয় খেলা" value={card.game} onChange={(v) => setField("game", v)} placeholder="খেলা: লাটিম" />
            <Field id="card-food" label="প্রিয় খাবার" value={card.food} onChange={(v) => setField("food", v)} placeholder="খাবার: ঝালমুড়ি" />
            <Field id="card-time" label="প্রিয় সময়" value={card.time} onChange={(v) => setField("time", v)} placeholder="সময়: বিকেল" />
          </div>
        </Step>

        <Step index={3} step={steps[3]}>
          <Field id="card-line" label="এক লাইনে আপনার শৈশব" icon={Quote} value={card.line} onChange={(v) => setField("line", v)} placeholder="যেমন: আমি ছিলাম পাড়ার সবার চেয়ে দুষ্টু!" />
        </Step>

        <button type="button" onClick={handleReset} className="mt-6 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-ink-3 hover:text-brick">
          <RotateCcw aria-hidden="true" className="size-4" />
          নতুন করে শুরু করুন
        </button>
      </form>

      {/* Live preview */}
      <section aria-label="কার্ডের প্রিভিউ" className="paper order-1 px-3 pt-6 pb-7 text-center sm:px-8 lg:order-none">
        <h2 className="font-display text-[21px] font-extrabold text-leaf md:text-[26px]">আপনার শৈশব পরিচয়পত্র</h2>
        <div className="mx-auto mt-4 max-w-[430px] -rotate-1 text-left">
          <div ref={cardRef} className="p-1">
            <IdCard card={{ ...card, name: card.name || "আপনার নাম" }} />
          </div>
        </div>
        <div className="sticky bottom-3 z-[5] mt-6 flex flex-wrap justify-center gap-3">
          <Button size="lg" onClick={handleDownload} disabled={status.type === "busy"}>
            <Download aria-hidden="true" className="size-5" />
            ডাউনলোড করুন
          </Button>
          <Button size="lg" variant="cream" onClick={handleShare} disabled={status.type === "busy"}>
            <Share2 aria-hidden="true" className="size-5" />
            শেয়ার করুন
          </Button>
        </div>
        <p role="status" className={`mt-3 min-h-6 text-sm font-semibold ${status.type === "error" ? "text-brick" : "text-leaf"}`}>
          {status.message}
        </p>
      </section>

      {/* Theme + ink */}
      <aside className="paper order-3 px-5 py-6 lg:col-span-2 xl:col-span-1">
        <h2 className="font-display text-xl font-bold text-leaf">থিম নির্বাচন করুন</h2>
        <p className="text-[13px] text-ink-3">আপনার পছন্দের ডিজাইনটি বেছে নিন।</p>
        <div role="radiogroup" aria-label="থিম" className="mt-3.5 grid grid-cols-3 gap-2.5">
          {cardThemes.map((theme) => {
            const selected = card.theme === theme.id;
            return (
              <button key={theme.id} type="button" role="radio" aria-checked={selected} onClick={() => setField("theme", theme.id)} className="text-center text-xs font-semibold text-ink-2">
                <span className={`mb-1.5 block aspect-[3/4] rounded-md border-2 ${themeSwatches[theme.id]} ${selected ? "border-leaf ring-2 ring-leaf-soft" : "border-[#e2d3b2]"}`} />
                {theme.label}
              </button>
            );
          })}
        </div>

        <hr className="my-6 border-dashed border-line" />

        <h2 className="font-display text-xl font-bold text-leaf">লেখার রং</h2>
        <p className="text-[13px] text-ink-3">কার্ডের তথ্যগুলো কোন কালিতে লেখা হবে।</p>
        <div role="radiogroup" aria-label="লেখার রং" className="mt-3 flex gap-2.5">
          {cardInks.map((ink) => {
            const selected = card.ink === ink.id;
            return (
              <button
                key={ink.id}
                type="button"
                role="radio"
                aria-checked={selected}
                aria-label={ink.label}
                onClick={() => setField("ink", ink.id)}
                className={`size-11 rounded-full border-[3px] border-card ${selected ? "ring-2 ring-leaf" : "ring-1 ring-[#d6c59f]"}`}
                style={{ background: ink.value }}
              />
            );
          })}
        </div>

        <Scrap className="relative mx-1.5 mt-8 hidden -rotate-4 text-lg xl:block">একটা ছোট কার্ড, অনেক বড় স্মৃতি… ♡</Scrap>
      </aside>
    </div>
  );
};

export default CardMaker;
