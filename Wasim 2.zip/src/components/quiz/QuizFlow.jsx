"use client";
import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import Button from "@/components/ui/Button";
import { questions, scoreQuiz } from "@/api/quiz";
import { toBn } from "@/lib/utils/format";
import { EASE } from "@/lib/utils/motion";

const letters = ["ক", "খ", "গ", "ঘ"];
const tints = ["bg-[#f3e2b3]", "bg-[#dfe6d6]", "bg-[#f3e2b3]", "bg-[#dbe3ec]"];
const badges = ["bg-brick", "bg-leaf", "bg-mustard", "bg-leaf"];

const QuizFlow = () => {
  const router = useRouter();
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState([]);
  const question = questions[index];
  const selected = answers[index];
  const isLast = index === questions.length - 1;

  const choose = (resultId) => {
    const next = [...answers];
    next[index] = resultId;
    setAnswers(next);
  };

  const goNext = () => {
    if (!selected) return;
    if (isLast) {
      router.push(`/quiz/result/${scoreQuiz(answers)}`);
      return;
    }
    setIndex(index + 1);
  };

  return (
    <div className="mx-auto w-full max-w-[760px]">
      <div className="flex items-center justify-between text-[15px] font-semibold text-ink-2">
        <p className="-rotate-2 bg-leaf px-4 py-1 font-display text-lg text-white">
          প্রশ্ন {toBn(index + 1)}/{toBn(questions.length)}
        </p>
        <p>প্রায় {toBn(questions.length - index)} মিনিট বাকি</p>
      </div>
      <div className="mt-4 grid grid-cols-5 gap-1.5" aria-hidden="true">
        {questions.map((item, i) => (
          <span key={item.id} className={`h-2 rounded-full ${i <= index ? "bg-leaf" : "bg-ink/10"}`} />
        ))}
      </div>

      <AnimatePresence mode="wait" initial={false}>
        <motion.fieldset
          key={question.id}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          transition={{ duration: 0.3, ease: EASE }}
          className="mt-10"
        >
          <legend className="text-center font-display text-[30px] leading-snug font-extrabold text-leaf md:text-5xl">{question.text}</legend>
          <p className="mt-3 text-center text-ink-2">সবচেয়ে কাছাকাছি উত্তরটা বেছে নাও।</p>

          <div className="mt-8 grid gap-3 md:grid-cols-2">
            {question.options.map((option, i) => {
              const isChosen = selected === option.result;
              return (
                <button
                  key={option.id}
                  type="button"
                  aria-pressed={isChosen}
                  onClick={() => choose(option.result)}
                  className={`relative flex min-h-24 items-center gap-4 rounded-md p-4 text-left shadow-[0_10px_22px_-16px_rgb(90_60_20/0.55)] transition-transform [background-image:var(--grain)] hover:-rotate-1 ${tints[i]} ${isChosen ? "ring-[3px] ring-leaf" : ""}`}
                >
                  <span className={`grid size-11 shrink-0 place-items-center rounded-full font-display text-xl font-bold text-white ${badges[i]}`}>{letters[i]}</span>
                  {option.image && (
                    <span className="relative hidden h-20 w-24 shrink-0 overflow-hidden rounded sm:block">
                      <Image src={option.image} alt="" fill sizes="96px" className="object-cover" />
                    </span>
                  )}
                  <span className="font-display text-lg leading-snug font-semibold text-ink md:text-xl">{option.label}</span>
                </button>
              );
            })}
          </div>
        </motion.fieldset>
      </AnimatePresence>

      <div className="mt-10 flex items-center justify-between">
        <Button variant="line" onClick={() => setIndex(index - 1)} disabled={index === 0}>
          <ArrowLeft aria-hidden="true" className="size-4" />
          আগের প্রশ্ন
        </Button>
        <Button variant="green" size="lg" onClick={goNext} disabled={!selected}>
          {isLast ? "ফলাফল দেখি" : "পরের প্রশ্ন"}
          <ArrowRight aria-hidden="true" className="size-5" />
        </Button>
      </div>
    </div>
  );
};

export default QuizFlow;
