import Image from "next/image";
import Link from "next/link";
import Icon from "@/components/ui/Icon";

const CategoryTile = ({ category }) => {
  return (
    <Link
      href={`/stories?cat=${category.id}`}
      className="group block rounded-md border border-[#e2d3b2] bg-card p-[7px] pb-3.5 shadow-[0_10px_22px_-16px_rgb(90_60_20/0.55)] transition-transform hover:-rotate-1"
    >
      <div className="relative aspect-[16/11] overflow-hidden rounded">
        <Image src={category.image} alt={category.label} fill sizes="(max-width: 768px) 62vw, 230px" placeholder="blur" className="object-cover transition-transform duration-500 group-hover:scale-105" />
      </div>
      <p className="flex items-center gap-2.5 px-1.5 pt-3 font-display text-[19px] font-bold text-leaf">
        <Icon name={category.icon} className="size-6" />
        {category.label}
      </p>
      <p className="px-1.5 pt-0.5 text-sm text-ink-3">{category.hint}</p>
    </Link>
  );
};

export default CategoryTile;
