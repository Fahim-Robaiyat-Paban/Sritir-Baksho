import Image from "next/image";
import Link from "next/link";
import { MessageCircle } from "lucide-react";
import { getStoryCategoryLabel } from "@/api/stories";
import { toBn } from "@/lib/utils/format";

const StoryCard = ({ story }) => {
  return (
    <Link
      href={`/stories/${story.slug}`}
      className="flex flex-col rounded-md border border-[#e2d3b2] bg-card p-2 pb-3 shadow-[0_10px_22px_-16px_rgb(90_60_20/0.55)] transition-transform hover:-rotate-1"
    >
      <span className="relative block aspect-[16/10] overflow-hidden rounded">
        <Image src={story.image} alt={story.title} fill sizes="(max-width: 640px) 80vw, (max-width: 1024px) 45vw, 280px" placeholder="blur" className="object-cover" />
      </span>
      <span className="block px-1.5 pt-3 font-display text-lg leading-snug font-bold text-ink">{story.title}</span>
      <span className="line-clamp-2 block px-1.5 pt-1 text-sm leading-relaxed text-ink-2">{story.excerpt}</span>
      <span className="mt-auto flex items-center justify-between px-1.5 pt-3 text-xs text-ink-3">
        <span>
          {getStoryCategoryLabel(story.category)} · {toBn(story.readMins)} মিনিট পড়া
        </span>
        <span className="flex items-center gap-1">
          <MessageCircle aria-hidden="true" className="size-3.5" />
          {toBn(story.comments)}
        </span>
      </span>
    </Link>
  );
};

export default StoryCard;
