import Image from "next/image";
import Link from "next/link";
import { FaFacebookF, FaInstagram, FaYoutube } from "react-icons/fa";
import { footerLinks, socialLinks } from "@/api/site";
import { bandMaskStyle } from "@/lib/utils/bandMask";
import logo from "@/assets/images/logo.svg";

// Darker pool of green behind each content group, same idea as the glow behind the card deck
const glow =
  "relative isolate before:pointer-events-none before:absolute before:-inset-x-10 before:-inset-y-5 before:-z-10 before:bg-[radial-gradient(closest-side,rgb(12_32_24/0.35),rgb(12_32_24/0.12)_60%,transparent)]";

const socialIcons = { facebook: FaFacebookF, youtube: FaYoutube, instagram: FaInstagram };

const Footer = () => {
  return (
    <footer className="relative z-[1] mt-16 text-[#e6dcc4] lg:mt-24">
      <div aria-hidden="true" className="absolute inset-0 -z-[1] bg-leaf [background-image:var(--grain)]" style={bandMaskStyle} />
      <div className="site-container flex flex-col gap-4 px-5 py-6 text-sm sm:px-8 lg:min-h-[72px] lg:flex-row lg:items-center lg:gap-10 lg:py-0 xl:px-0">
        <Link href="/" className={`${glow} flex items-center gap-2.5 font-display text-[26px] leading-none font-extrabold text-white`}>
          <Image src={logo} alt="" width={42} height={35} />
          স্মৃতির বাক্স
        </Link>
        <p className={glow}>শৈশব শুধু একটা সময় নয়, এটা একটা অনুভূতি</p>
        <nav aria-label="ফুটার" className={`${glow} flex flex-wrap gap-x-6 gap-y-1 lg:ml-auto`}>
          {footerLinks.map((link) => (
            <Link key={link.id} href={link.href} className="inline-flex min-h-11 items-center hover:text-white">
              {link.label}
            </Link>
          ))}
        </nav>
        <ul className={`${glow} flex gap-2`}>
          {socialLinks.map((social) => {
            const Glyph = socialIcons[social.id];
            return (
              <li key={social.id}>
                <a href={social.href} target="_blank" rel="noreferrer" aria-label={social.label} className="grid size-11 place-items-center hover:text-white">
                  <Glyph className="size-[18px]" />
                </a>
              </li>
            );
          })}
        </ul>
      </div>
      <p className="relative isolate border-t border-white/10 py-2.5 text-center text-xs text-[#cfc4a8]">© ২০২৫ স্মৃতির বাক্স</p>
    </footer>
  );
};

export default Footer;
