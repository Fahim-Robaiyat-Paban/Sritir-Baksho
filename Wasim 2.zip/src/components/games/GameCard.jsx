import Image from "next/image";
import Link from "next/link";
import { getCategoryLabel } from "@/api/games";

const GameCard = ({ game }) => {
  return (
    <Link
      href={`/games/${game.slug}`}
      className="group block rounded-md border border-[#e2d3b2] bg-card p-2 pb-3.5 shadow-[0_10px_22px_-16px_rgb(90_60_20/0.55)] transition-transform hover:-rotate-1"
    >
      <span className="relative block aspect-[16/10] overflow-hidden rounded">
        <Image src={game.image} alt={game.name} fill sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 280px" placeholder="blur" className="object-cover" />
      </span>
      <span className="block px-1.5 pt-3 font-display text-lg leading-snug font-bold text-leaf md:text-xl">{game.name}</span>
      <span className="block px-1.5 text-sm leading-snug text-ink-2">{game.line}</span>
      <span className="mx-1.5 mt-2.5 inline-flex rounded-full bg-marker/35 px-2.5 py-0.5 text-xs font-semibold text-ink-2">
        {getCategoryLabel(game.category)}
      </span>
    </Link>
  );
};

export default GameCard;
