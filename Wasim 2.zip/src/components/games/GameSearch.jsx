"use client";
import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Search } from "lucide-react";

// Debounced search that writes ?q= into the URL, keeping the active category
const GameSearch = ({ category, initialQuery }) => {
  const router = useRouter();
  const pathname = usePathname();
  const [value, setValue] = useState(initialQuery);

  useEffect(() => {
    const query = value.trim();
    if (query === initialQuery) return undefined;
    const timer = setTimeout(() => {
      const params = new URLSearchParams();
      if (category !== "all") params.set("cat", category);
      if (query) params.set("q", query);
      const search = params.toString();
      router.replace(search ? `${pathname}?${search}` : pathname, { scroll: false });
    }, 300);
    return () => clearTimeout(timer);
  }, [value, category, initialQuery, pathname, router]);

  return (
    <div className="flex h-12 items-center gap-3 rounded-full border-[1.5px] border-[#cdbb95] bg-card/70 px-5 focus-within:border-leaf">
      <Search aria-hidden="true" className="size-[18px] text-ink-2" />
      <label htmlFor="game-search" className="sr-only">খেলা খুঁজুন</label>
      <input
        id="game-search"
        type="search"
        value={value}
        onChange={(event) => setValue(event.target.value)}
        placeholder="কোন খেলা খুঁজছেন?"
        className="w-full bg-transparent text-base outline-none placeholder:text-ink-3"
      />
    </div>
  );
};

export default GameSearch;
